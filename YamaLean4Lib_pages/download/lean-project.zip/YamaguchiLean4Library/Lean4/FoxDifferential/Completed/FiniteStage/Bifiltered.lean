import FoxDifferential.Completed.FiniteStage.Bifiltered.Transition
import FoxDifferential.Completed.FiniteStage.Bifiltered.System
import FoxDifferential.Completed.FiniteStage.Bifiltered.InverseSystem

/-
PUBLIC_PAGE_SNAPSHOT
generated_at: 2026-05-27T09:47:29+09:00
lean_source: lean4/FoxDifferential/Completed/FiniteStage/Bifiltered.lean
translation_root: data/translation
purpose: identifies the local data snapshot used to build pages/
placement: after imports, never before imports
-/
/-!
# Finite-stage completed Fox calculus

Finite quotient stages are used to compare completed Fox boundaries, derivatives, and relation modules with explicit finite group-algebra calculations.
-/
